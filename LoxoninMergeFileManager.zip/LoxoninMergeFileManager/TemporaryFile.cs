﻿using System;
using System.IO;

namespace LoxoninMergeFileManager
{
    sealed class TemporaryFile : IDisposable
    {
        internal string Path
        {
            get;
            private set;
        }

        readonly string subdirectoryPath;

        internal TemporaryFile()
        {
            Path = System.IO.Path.Combine(System.IO.Path.GetTempPath(), System.IO.Path.GetRandomFileName());
        }

        internal TemporaryFile(string fileName)
        {
            // Create a subdirectory in case the fileName exists and is locked.
            subdirectoryPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), DateTime.Now.ToString("yyyyMMdd-hhmmss.fffffff"));

            Directory.CreateDirectory(subdirectoryPath);

            Path = System.IO.Path.Combine(subdirectoryPath, fileName);
        }

        public void Dispose()
        {
            if (Directory.Exists(subdirectoryPath))
            {
                U.TryDeleteDirectory(subdirectoryPath);
            }
            else
            {
                U.TryDeleteFile(Path);
            }
        }
    }
}