﻿using System;
using System.IO;
using System.Threading;

namespace LoxoninMergeFileManager
{
    static class FilePoller
    {
        static Timer timer;

        internal static void Start()
        {
            timer = new Timer(state =>
            {
                const string path = "x";

                if (File.Exists(path))
                {
                    File.Delete(path);
                    timer.Dispose();
                    Environment.Exit(0);
                }
            }, null, TimeSpan.Zero, TimeSpan.FromMinutes(1));
        }
    }
}