﻿using System;

namespace LoxoninMergeFileManager
{
    public sealed class Record
    {
        public string Name
        {
            get;
            set;
        }

        public string CreatedBy
        {
            get;
            set;
        }

        public DateTime CreatedAt
        {
            get;
            set;
        }

        public Record(string name, string createdBy, DateTime createdAt)
        {
            Name = name;
            CreatedBy = createdBy;
            CreatedAt = createdAt;
        }
    }
}