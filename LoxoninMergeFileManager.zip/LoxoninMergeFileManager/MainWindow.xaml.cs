﻿using LoxoninMergeFileManager.Db;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace LoxoninMergeFileManager
{
    public sealed partial class MainWindow : Window
    {
        Point startPosition;

        public MainWindow()
        {
            InitializeComponent();

            U.KillOldSelf();

            if (!Mtndb01.GetUsers().Contains(Environment.UserName))
            {
                MessageBox.Show("IACにて「MTN Anken Tool」の使用申請をしてください。");
                Close();
            }

            Title += U.CreateBreadcrumbForMergeFile() + U.CreateBreadcrumbForUserAuthentication();

            DataGrid1.ItemsSource = Mtndb01OrAnken.GetFiles();

            FilePoller.Start();
        }

        void Delete_Click(object sender, RoutedEventArgs e)
        {
            Delete();
        }

        void DataGrid1_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            startPosition = e.GetPosition(null);
        }

        void DataGrid1_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            var v = startPosition - e.GetPosition(null);

            if (e.LeftButton == MouseButtonState.Pressed && (
                SystemParameters.MinimumHorizontalDragDistance < Math.Abs(v.X) ||
                SystemParameters.MinimumVerticalDragDistance < Math.Abs(v.Y)))
            {
                var record = (Record)DataGrid1.SelectedItem;

                if (record == null)
                {
                    return;
                }

                using (var tf = new TemporaryFile(record.Name))
                {
                    File.WriteAllBytes(tf.Path, Mtndb01OrAnken.Download(record.Name));

                    U.DragDrop1((DependencyObject)sender, tf.Path);
                }
            }
        }

        private void DataGrid1_PreviewMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var record = (Record)DataGrid1.SelectedItem;

            if (record == null)
            {
                return;
            }

            using (var tf = new TemporaryFile(record.Name))
            {
                File.WriteAllBytes(tf.Path, Mtndb01OrAnken.Download(record.Name));
                var p = Process.Start(tf.Path);

                if (p != null)
                {
                    p.WaitForExit();
                }
            }
        }

        void DataGrid1_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Delete)
            {
                Delete();
            }
        }

        void Window_PreviewDrop(object sender, DragEventArgs e)
        {
            if (!e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                return;
            }

            foreach (var filePath in (string[])e.Data.GetData(DataFormats.FileDrop))
            {
                var fileName = Path.GetFileName(filePath);

                if (DataGrid1.Items.Cast<Record>().Select(r => r.Name).Contains(fileName))
                {
                    Pop("The name \"{0}\" is already taken.", fileName);
                    continue;
                }

                Mtndb01OrAnken.Upload(fileName, File.ReadAllBytes(filePath));
            }

            DataGrid1.ItemsSource = Mtndb01OrAnken.GetFiles();
        }

        void Delete()
        {
            var record = (Record)DataGrid1.SelectedItem;

            if (record == null || MessageBox.Show("Delete?", "", MessageBoxButton.OKCancel) == MessageBoxResult.Cancel)
            {
                return;
            }

            Mtndb01OrAnken.Delete(record.Name);

            DataGrid1.ItemsSource = Mtndb01OrAnken.GetFiles();
        }

        void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
            }
        }

        static void Pop(string format, params object[] args)
        {
            MessageBox.Show(string.Format(format, args));
        }
    }
}