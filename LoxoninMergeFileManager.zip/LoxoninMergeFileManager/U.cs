﻿using LoxoninMergeFileManager.Db;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;

namespace LoxoninMergeFileManager
{
    static class U
    {
        internal static void KillOldSelf()
        {
            var me = Process.GetCurrentProcess();

            foreach (var p in Process.GetProcessesByName(me.ProcessName).Where(p => p.Id != me.Id))
            {
                p.Kill();
            }
        }

        internal static string CreateBreadcrumbForMergeFile()
        {
            return string.Format(" ({0} > {1} > {2})", Mtndb01OrAnken.Scsb.DataSource, Mtndb01OrAnken.Scsb.InitialCatalog, Mtndb01OrAnken.Table);
        }

        internal static string CreateBreadcrumbForUserAuthentication()
        {
            return string.Format(" ({0} > {1} > AnkenUser)", Mtndb01.Scsb.DataSource, Mtndb01.Scsb.InitialCatalog);
        }

        internal static void DragDrop1(DependencyObject dragSource, string path)
        {
            // DoDragDrop needs to be called before the left button is up, not when the left button is up.
            DragDrop.DoDragDrop(dragSource, new DataObject(DataFormats.FileDrop, new[] { path }), DragDropEffects.Copy);
        }

        internal static void TryDeleteDirectory(string path)
        {
            try
            {
                if (Directory.Exists(path))
                {
                    Directory.Delete(path, true);
                }
            }
            catch
            {
            }
        }

        internal static void TryDeleteFile(string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
            catch
            {
            }
        }
    }
}