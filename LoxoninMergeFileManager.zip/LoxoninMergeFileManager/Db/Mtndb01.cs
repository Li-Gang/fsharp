﻿using ConnectionStringFactories;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace LoxoninMergeFileManager.Db
{
    static class Mtndb01
    {
        internal static readonly SqlConnectionStringBuilder Scsb;

        static Mtndb01()
        {
            switch (ConnectionStringFactory.GetDeploymentEnvironment())
            {
                case DeploymentEnvironment.Production:
                    Scsb = ConnectionStringFactory.Create(DatabaseServer.Production, "mtndb01");
                    break;
                case DeploymentEnvironment.UAT1:
                    Scsb = ConnectionStringFactory.Create(DatabaseServer.Development, "mtndb01_uat3");
                    break;
                case DeploymentEnvironment.UAT2:
                    Scsb = ConnectionStringFactory.Create(DatabaseServer.Development, "mtndb01_uat3");
                    break;
            }
        }

        internal static HashSet<string> GetUsers()
        {
            using (var sc = new SqlConnection(Scsb.ConnectionString))
            {
                sc.Open();
                using (var c = sc.CreateCommand())
                {
                    c.CommandText = "SELECT Name FROM mtndb01_dbo.AnkenUser";
                    using (var r = c.ExecuteReader())
                    {
                        var users = new HashSet<string>();
                        while (r.Read())
                        {
                            users.Add(r.GetString(0));
                        }
                        return users;
                    }
                }
            }
        }
    }
}