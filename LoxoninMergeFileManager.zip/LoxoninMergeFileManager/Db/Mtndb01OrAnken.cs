﻿using ConnectionStringFactories;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace LoxoninMergeFileManager.Db
{
    static class Mtndb01OrAnken
    {
        internal static readonly SqlConnectionStringBuilder Scsb;
        internal static readonly string Table;

        static Mtndb01OrAnken()
        {
            switch (ConnectionStringFactory.GetDeploymentEnvironment())
            {
                case DeploymentEnvironment.Production:
                    Scsb = ConnectionStringFactory.Create(DatabaseServer.Production, "mtndb01");
                    Table = "mtndb01_dbo.LoxoninMergeFile";
                    break;
                case DeploymentEnvironment.UAT1:
                    Scsb = ConnectionStringFactory.Create(DatabaseServer.Development, "Anken");
                    Table = "LoxoninMergeFile1";
                    break;
                case DeploymentEnvironment.UAT2:
                    Scsb = ConnectionStringFactory.Create(DatabaseServer.Development, "Anken");
                    Table = "LoxoninMergeFile2";
                    break;
            }
        }

        internal static List<Record> GetFiles()
        {
            using (var sc = new SqlConnection(Scsb.ConnectionString))
            {
                sc.Open();
                using (var c = sc.CreateCommand())
                {
                    c.CommandText = string.Format("SELECT Name, CreatedBy, CreatedAt FROM {0} ORDER BY Name", Table);
                    var records = new List<Record>();
                    using (var r = c.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            records.Add(new Record(r.GetString(0), r.GetString(1), r.GetDateTime(2)));
                        }
                    }
                    return records.ToList();
                }
            }
        }

        internal static byte[] Download(string name)
        {
            using (var sc = new SqlConnection(Scsb.ConnectionString))
            {
                sc.Open();
                using (var c = sc.CreateCommand())
                {
                    c.CommandText = string.Format("SELECT Docx FROM {0} WHERE Name = @Name", Table);
                    c.Parameters.AddWithValue("@Name", name);
                    return (byte[])c.ExecuteScalar();
                }
            }
        }

        internal static void Upload(string name, byte[] docx)
        {
            using (var sc = new SqlConnection(Scsb.ConnectionString))
            {
                sc.Open();
                using (var c = sc.CreateCommand())
                {
                    c.CommandText = string.Format("INSERT INTO {0} (Name, Docx, CreatedBy) VALUES (@Name, @Docx, @CreatedBy)", Table);
                    c.Parameters.AddWithValue("@Name", name);
                    c.Parameters.AddWithValue("@Docx", docx);
                    c.Parameters.AddWithValue("@CreatedBy", Environment.UserName);
                    c.ExecuteNonQuery();
                }
            }
        }

        internal static void Delete(string name)
        {
            using (var sc = new SqlConnection(Scsb.ConnectionString))
            {
                sc.Open();
                using (var c = sc.CreateCommand())
                {
                    c.CommandText = string.Format("DELETE FROM {0} WHERE Name = @Name", Table);
                    c.Parameters.AddWithValue("@Name", name);
                    c.ExecuteNonQuery();
                }
            }
        }
    }
}