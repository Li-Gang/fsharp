﻿using System.Windows;

namespace LoxoninMergeFileManager
{
    public sealed partial class App : Application
    {
    }
}
